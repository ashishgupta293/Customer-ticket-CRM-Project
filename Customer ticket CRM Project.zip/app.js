const minutesAgo = minutes => new Date(Date.now() - minutes * 60 * 1000).toISOString();
const seedTickets = [
  { id: 1, customer: 'Rohit Sharma', initials: 'RS', customerEmail: 'rohit.sharma@example.com', subject: 'Unable to update billing information', channel: 'Email', priority: 'High', status: 'Open', time: '8m', createdAt: minutesAgo(68), updatedAt: minutesAgo(8) },
  { id: 2, customer: 'Umesh Prajapati', initials: 'UP', customerEmail: 'umesh.prajapati@example.com', subject: 'Order #38492 hasn’t arrived yet', channel: 'Chat', priority: 'High', status: 'Open', time: '22m', createdAt: minutesAgo(82), updatedAt: minutesAgo(22) },
  { id: 3, customer: 'Priya Sharma', initials: 'PS', customerEmail: 'priya.sharma@example.com', subject: 'Question about annual plan pricing', channel: 'Email', priority: 'Medium', status: 'Pending', time: '45m', createdAt: minutesAgo(130), updatedAt: minutesAgo(45) },
  { id: 4, customer: 'Neha Shah', initials: 'NS', customerEmail: 'neha.shah@example.com', subject: 'Cannot access team workspace', channel: 'Chat', priority: 'Medium', status: 'Open', time: '1h', createdAt: minutesAgo(215), updatedAt: minutesAgo(60) },
  { id: 5, customer: 'Amit Singh', initials: 'AS', customerEmail: 'amit.singh@example.com', subject: 'Requesting invoice for April', channel: 'Email', priority: 'Low', status: 'Resolved', time: '2h', createdAt: minutesAgo(355), updatedAt: minutesAgo(120) },
  { id: 6, customer: 'Raj Patel', initials: 'RP', customerEmail: 'raj.patel@example.com', subject: 'Export file is missing customer fields', channel: 'Email', priority: 'High', status: 'Pending', time: '3h', createdAt: minutesAgo(490), updatedAt: minutesAgo(180) },
  { id: 7, customer: 'Tannya Yadav', initials: 'TY', customerEmail: 'tannya.yadav@example.com', subject: 'How do I change my notification preferences?', channel: 'Chat', priority: 'Low', status: 'Resolved', time: '4h', createdAt: minutesAgo(570), updatedAt: minutesAgo(240) }
];

const storageKey = 'helpdesk-crm-tickets-v1';
const settingsKey = 'helpdesk-crm-settings-v1';
const palettes = ['#8c78d5', '#68a6c7', '#d88986', '#7ab392', '#ce9a64', '#778bc6', '#c678a0'];
const safe = value => String(value).replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
const formatTimestamp = timestamp => new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(timestamp));

function renderLiveDate() {
  document.querySelector('#liveDateLabel').textContent = new Intl.DateTimeFormat('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date()).toUpperCase();
}

function loadTickets() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey));
    const source = Array.isArray(saved) ? saved : seedTickets;
    return source.map((ticket, index) => ({
      ...ticket,
      customerEmail: ticket.customerEmail || `${ticket.customer.toLowerCase().replace(/\s+/g, '.')}@example.com`,
      createdAt: ticket.createdAt || seedTickets[index]?.createdAt || new Date().toISOString(),
      updatedAt: ticket.updatedAt || ticket.createdAt || seedTickets[index]?.updatedAt || new Date().toISOString()
    }));
  } catch {
    return seedTickets;
  }
}

const tickets = loadTickets();
const saveTickets = () => localStorage.setItem(storageKey, JSON.stringify(tickets));
const settings = { autoClose: true, liveReports: true, notifications: false, ...JSON.parse(localStorage.getItem(settingsKey) || '{}') };
const saveSettings = () => localStorage.setItem(settingsKey, JSON.stringify(settings));
saveTickets();
const row = ticket => `<div class="ticket-row" data-ticket="${ticket.id}"><span class="priority-dot ${ticket.priority}"></span><div><h3><span class="ticket-id">#${ticket.id}</span>${safe(ticket.subject)}</h3><p><b>${safe(ticket.customer)}</b> · ${safe(ticket.channel)} · ${safe(ticket.customerEmail)}</p></div><span class="pill ${ticket.status}">${ticket.status}</span><time>${ticket.time}</time></div>`;

function renderTickets() {
  document.querySelector('#priorityTickets').innerHTML = tickets.filter(ticket => ticket.priority === 'High' && ticket.status !== 'Resolved').slice(0, 4).map(row).join('');
  const term = document.querySelector('#ticketSearch').value.toLowerCase();
  const status = document.querySelector('#statusFilter').value;
  const priority = document.querySelector('#priorityFilter').value;
  const filtered = tickets.filter(ticket => (status === 'all' || ticket.status === status) && (priority === 'all' || ticket.priority === priority) && `${ticket.customer} ${ticket.customerEmail} ${ticket.subject} ${ticket.id}`.toLowerCase().includes(term));
  document.querySelector('#allTickets').innerHTML = filtered.map(row).join('') || '<p class="empty">No tickets match those filters.</p>';
  document.querySelector('#openCount').textContent = tickets.filter(ticket => ticket.status === 'Open').length;
  document.querySelector('#metricOpen').textContent = 19 + tickets.filter(ticket => ticket.status === 'Open').length;
}

function renderCustomers() {
  const unique = tickets.filter((ticket, index, all) => all.findIndex(item => item.customerEmail === ticket.customerEmail) === index);
  document.querySelector('#customerCards').innerHTML = unique.map((ticket, index) => `<article class="panel customer-card"><header><div class="avatar" style="background:${palettes[index % palettes.length]}">${ticket.initials}</div><div><h2>${safe(ticket.customer)}</h2><p>${safe(ticket.customerEmail)}</p></div></header><dl><div><dt>Open tickets</dt><dd>${tickets.filter(item => item.customerEmail === ticket.customerEmail && item.status === 'Open').length} active</dd></div><div><dt>Last contact</dt><dd>${formatTimestamp(ticket.updatedAt)}</dd></div><div><dt>Plan</dt><dd>${index % 2 ? 'Business' : 'Pro'}</dd></div><div><dt>Created at</dt><dd>${formatTimestamp(ticket.createdAt)}</dd></div></dl></article>`).join('');
}

function renderReports() {
  const today = new Date();
  const dates = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (6 - index));
    date.setHours(0, 0, 0, 0);
    return date;
  });
  const volumes = dates.map(date => tickets.filter(ticket => {
    const created = new Date(ticket.createdAt);
    return created.getFullYear() === date.getFullYear() && created.getMonth() === date.getMonth() && created.getDate() === date.getDate();
  }).length);
  const maxVolume = Math.max(...volumes, 1);
  const resolved = tickets.filter(ticket => ticket.status === 'Resolved').length;
  const open = tickets.filter(ticket => ticket.status === 'Open').length;
  const pending = tickets.filter(ticket => ticket.status === 'Pending').length;
  const rate = tickets.length ? Math.round((resolved / tickets.length) * 100) : 0;
  document.querySelector('#barChart').innerHTML = volumes.map(value => `<i style="height:${Math.max((value / maxVolume) * 100, value ? 8 : 2)}%" title="${value} tickets"></i>`).join('');
  document.querySelector('#chartDays').innerHTML = dates.map(date => `<span>${date.toLocaleDateString('en-IN', { weekday: 'short' })}</span>`).join('');
  document.querySelector('#reportTotal').textContent = tickets.length;
  document.querySelector('#resolutionRate').textContent = rate;
  document.querySelector('#resolutionStars').textContent = '★'.repeat(Math.round(rate / 20)) + '☆'.repeat(5 - Math.round(rate / 20));
  document.querySelector('#resolutionText').textContent = `${resolved} resolved tickets from ${tickets.length} total`;
  document.querySelector('#reportOpen').textContent = open;
  document.querySelector('#reportPending').textContent = pending;
  document.querySelector('#reportUpdated').textContent = `Updated ${new Intl.DateTimeFormat('en-IN', { timeStyle: 'medium' }).format(new Date())}`;
}

function renderSettings() {
  document.querySelectorAll('[data-setting]').forEach(input => { input.checked = Boolean(settings[input.dataset.setting]); });
}

function showDetail(id) {
  const ticket = tickets.find(item => item.id === Number(id));
  if (!ticket) return;
  document.querySelector('#ticketDetail').innerHTML = `<div class="detail"><button class="close" onclick="detailDialog.close()">×</button><div class="detail-top"><div class="avatar">${ticket.initials}</div><div><p class="eyebrow">TICKET #${ticket.id}</p><h2>${safe(ticket.subject)}</h2><p>${safe(ticket.customer)} · ${safe(ticket.customerEmail)}</p></div></div><div class="detail-meta"><span class="pill ${ticket.status}">${ticket.status}</span><span class="pill" style="background:#f5f4f7;color:#716b7c">${ticket.priority} priority</span></div><p>Hi team, I need some help with this issue. I’ve tried the usual steps but haven’t been able to resolve it. Could you please take a look and let me know what to do next?</p><div class="timestamp-summary"><span><b>Created at</b>${formatTimestamp(ticket.createdAt)}</span><span><b>Updated at</b>${formatTimestamp(ticket.updatedAt)}</span></div><div class="reply"><label>Reply to ${safe(ticket.customer)}<textarea placeholder="Write a helpful response..."></textarea></label><div class="reply-row"><span class="pill" style="background:#f5f4f7;color:#716b7c">Public reply</span><button class="primary-button" onclick="sendReply(${ticket.id})">${settings.autoClose ? 'Send & close' : 'Send reply'}</button></div></div></div>`;
  detailDialog.showModal();
}

function sendReply(id) {
  const ticket = tickets.find(item => item.id === id);
  ticket.status = settings.autoClose ? 'Resolved' : 'Pending';
  ticket.updatedAt = new Date().toISOString();
  saveTickets();
  detailDialog.close();
  renderTickets();
  renderCustomers();
  renderReports();
}

document.querySelectorAll('.nav-item[data-view]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('.nav-item[data-view], .view').forEach(element => element.classList.remove('active'));
  button.classList.add('active');
  document.querySelector(`#${button.dataset.view}View`).classList.add('active');
}));
document.querySelector('[data-view-target]').addEventListener('click', () => document.querySelector('[data-view="tickets"]').click());
document.querySelectorAll('[data-new-ticket], #newTicketBtn').forEach(button => button.addEventListener('click', () => ticketDialog.showModal()));
document.querySelector('#ticketForm').addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(event.target);
  const emailInput = event.target.elements.customerEmail;
  const customerEmail = data.get('customerEmail').trim().toLowerCase();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  emailInput.setCustomValidity(emailPattern.test(customerEmail) ? '' : 'Enter a valid email address, for example name@example.com.');
  if (!emailInput.reportValidity()) return;
  const now = new Date().toISOString();
  tickets.unshift({ id: Math.max(...tickets.map(ticket => ticket.id)) + 1, customer: data.get('customer'), customerEmail, initials: data.get('customer').split(' ').map(part => part[0]).join('').slice(0, 2).toUpperCase(), subject: data.get('subject'), channel: 'Web', priority: data.get('priority'), status: 'Open', time: 'now', createdAt: now, updatedAt: now });
  saveTickets();
  ticketDialog.close();
  event.target.reset();
  renderTickets();
  renderCustomers();
  renderReports();
});
document.querySelector('#ticketForm').elements.customerEmail.addEventListener('input', event => event.target.setCustomValidity(''));
document.addEventListener('click', event => { const item = event.target.closest('[data-ticket]'); if (item) showDetail(item.dataset.ticket); });
['ticketSearch', 'statusFilter', 'priorityFilter'].forEach(id => document.querySelector(`#${id}`).addEventListener('input', renderTickets));
document.querySelectorAll('[data-setting]').forEach(input => input.addEventListener('change', event => { settings[event.target.dataset.setting] = event.target.checked; saveSettings(); renderSettings(); renderReports(); }));
document.querySelector('#globalSearch').addEventListener('input', event => { const term = event.target.value.trim(); if (term) { document.querySelector('[data-view="tickets"]').click(); document.querySelector('#ticketSearch').value = term; renderTickets(); } });
renderTickets();
renderCustomers();
renderReports();
renderSettings();
renderLiveDate();
setInterval(() => { if (settings.liveReports) renderReports(); }, 30000);
setInterval(renderLiveDate, 60000);
