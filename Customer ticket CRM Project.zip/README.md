# CareDesk Ticketing CRM

A responsive, front-end customer-support ticketing CRM built with plain HTML, CSS, and JavaScript.

## Run it

Open `index.html` in any modern browser. No install or build step is needed.

## Included

- Overview dashboard and priority queue
- Ticket search plus status/priority filtering
- New-ticket form and ticket-detail replies
- Customer directory and lightweight reports
- Responsive desktop and mobile layouts
- Local persistence for customer emails and ticket timestamps

## Database

The browser demo persists ticket data with local storage. For a server-side database, use the PostgreSQL schema in `database/schema.sql`, which includes customer email addresses and `created_at` / `updated_at` timestamp fields.
